/**
 * Grocery CRUD - JavaScript functionality
 * Handles AJAX CRUD operations, form submissions, and UI interactions
 */
(function ($) {
    'use strict';

    // ======== Alert Handler ========
    function showAlert(message, type) {
        type = type || 'success';
        var icon = type === 'success' ? 'bi-check-circle-fill'
                 : type === 'danger' ? 'bi-exclamation-triangle-fill'
                 : type === 'warning' ? 'bi-exclamation-circle-fill'
                 : 'bi-info-circle-fill';

        var alertHtml = '<div class="gc-alert alert alert-' + type + ' alert-dismissible fade show shadow" role="alert">'
            + '<i class="bi ' + icon + ' me-2"></i>' + message
            + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'
            + '</div>';

        var $alert = $(alertHtml);
        $('body').append($alert);

        setTimeout(function () {
            $alert.alert('close');
        }, 4000);
    }

    // ======== Loading Overlay ========
    function showLoading() {
        if ($('.gc-loading').length === 0) {
            $('body').append('<div class="gc-loading"></div>');
        }
    }

    function hideLoading() {
        $('.gc-loading').remove();
    }

    // ======== Modal Manager ========
    var GcModal = {
        show: function (html) {
            this.remove();
            var modalHtml = '<div class="modal fade gc-modal" tabindex="-1" role="dialog">'
                + '<div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">'
                + '<div class="modal-content">'
                + '<div class="modal-body p-0">'
                + html
                + '</div>'
                + '</div>'
                + '</div>'
                + '</div>';

            var $modal = $(modalHtml);
            $('body').append($modal);
            $modal.modal('show');

            // Initialize Materialize form elements if Materialize is loaded
            if (typeof M !== 'undefined') {
                M.updateTextFields();

                // Fix labels for selects and textareas in input-field
                // (M.updateTextFields only handles text inputs)
                $('.gc-modal .input-field select, .gc-modal .input-field textarea').each(function () {
                    var $input = $(this);
                    var $label = $input.siblings('label');
                    if ($input.val() && !$label.hasClass('active')) {
                        $label.addClass('active');
                    }
                });
            }

            return $modal;
        },
        hide: function () {
            $('.gc-modal').modal('hide');
        },
        remove: function () {
            $('.gc-modal').remove();
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open');
        }
    };

    // ======== Form Serializer (handles checkboxes) ========
    function serializeForm($form) {
        var data = {};
        var formArray = $form.serializeArray();

        // Handle checkboxes
        $form.find('input[type="checkbox"]').each(function () {
            var $cb = $(this);
            if ($cb.prop('checked')) {
                if (data[$cb.attr('name')] === undefined) {
                    data[$cb.attr('name')] = [];
                }
                data[$cb.attr('name')].push($cb.val());
            }
        });

        // Overwrite with serializeArray values (for non-checkbox inputs)
        $.each(formArray, function (i, field) {
            if (field.name.indexOf('[]') === -1) {
                data[field.name] = field.value;
            } else {
                var name = field.name.replace('[]', '');
                if (data[name] === undefined) {
                    data[name] = [];
                }
                // Only add if not already added by checkbox handler
                if ($.inArray(field.value, data[name]) === -1) {
                    data[name].push(field.value);
                }
            }
        });

        return data;
    }

    // ======== File Upload FormData ========
    function buildFormData($form) {
        var formData = new FormData($form[0]);
        var mode = $form.data('mode');

        // Add the CRUD action (missing from FormData)
        formData.append('gc_action', mode);

        // Handle checkboxes not in FormData automatically
        $form.find('input[type="checkbox"]:not(:checked)').each(function () {
            var $cb = $(this);
            var name = $cb.attr('name');
            // Skip array fields (e.g., tags[]) — they're only meaningful when checked.
            // Setting '0' on an array field makes PHP see ['0'], which causes FK errors.
            if (name.indexOf('[]') !== -1) {
                return;
            }
            // FormData doesn't include unchecked checkboxes
            // We need to ensure the field is present
            if (!formData.has(name)) {
                formData.set(name, '0');
            }
        });

        return formData;
    }

    // ======== CRUD Operations ========
    function refreshList($wrapper) {
        var crudId = $wrapper.attr('id');
        var $parent = $wrapper.parent();
        var page = $wrapper.data('currentPage') || 1;
        var $searchInput = $wrapper.find('.gc-search-input');
        var search = $searchInput.val() || '';
        var advancedFilters = $wrapper.data('gcAdvancedFilters') || [];
        var sortField = $wrapper.data('sortField') || null;
        var sortDir = $wrapper.data('sortDir') || null;
        var wasFocused = document.activeElement === $searchInput[0];
        var caretPos = wasFocused && $searchInput[0].selectionStart !== undefined
            ? $searchInput[0].selectionStart
            : -1;

        // Track filter input focus for restore after DOM replacement
        var $focusedFilter = $wrapper.find('.gc-column-filter:focus');
        var wasFilterFocused = $focusedFilter.length > 0;
        var focusedFilterField = wasFilterFocused ? $focusedFilter.data('filter-field') : null;
        var filterCaretPos = wasFilterFocused && $focusedFilter[0].selectionStart !== undefined
            ? $focusedFilter[0].selectionStart
            : -1;

        // Save hidden columns state before refresh (columns menu will be regenerated)
        var hiddenColumns = [];
        $wrapper.find('.gc-columns-menu input[type="checkbox"]').each(function () {
            if (!$(this).is(':checked')) {
                hiddenColumns.push($(this).data('column'));
            }
        });

        // Collect column filters from DOM
        var filters = {};
        $wrapper.find('.gc-column-filter').each(function () {
            var $el = $(this);
            var field = $el.data('filter-field');
            var val = $el.val();
            if (val) {
                filters[field] = val;
            }
        });

        showLoading();

        $.ajax({
            url: window.location.href,
            method: 'GET',
            data: {
                gc_action: 'list',
                page: page,
                search: search,
                sort_field: sortField,
                sort_dir: sortDir,
                filters: Object.keys(filters).length > 0 ? JSON.stringify(filters) : undefined,
                advanced_filters: JSON.stringify(advancedFilters)
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    $wrapper.replaceWith(response.html);
                    // Re-bind events
                    bindEvents();
                    // Restore search value (crudId changes on re-render via uniqid)
                    var $newSearchInput = $parent.find('.grocery-crud-wrapper .gc-search-input');
                    $newSearchInput.val(search);
                    // Restore advanced filters
                    var savedFilters = $wrapper.data('gcAdvancedFilters');
                    if (savedFilters && savedFilters.length) {
                        $wrapper.data('gcAdvancedFilters', savedFilters);
                    }
                    // Restore focus and caret position if previously focused
                    if (wasFocused) {
                        $newSearchInput.focus();
                        if (caretPos >= 0 && $newSearchInput[0].setSelectionRange) {
                            $newSearchInput[0].setSelectionRange(caretPos, caretPos);
                        }
                    }
                    // Sync clear button visibility (fresh HTML always has it hidden)
                    var $clearBtn = $newSearchInput.closest('.input-group').find('.gc-search-clear');
                    if (search) {
                        $clearBtn.show();
                    } else {
                        $clearBtn.hide();
                    }
                    // Restore focus to filter input if previously focused
                    if (wasFilterFocused && focusedFilterField) {
                        var $newFilter = $parent.find('.grocery-crud-wrapper .gc-column-filter[data-filter-field="' + focusedFilterField + '"]');
                        if ($newFilter.length) {
                            $newFilter.focus();
                            if (filterCaretPos >= 0 && $newFilter[0].setSelectionRange) {
                                $newFilter[0].setSelectionRange(filterCaretPos, filterCaretPos);
                            }
                        }
                    }
                    // Populate columns menu and filter selects from table headers
                    var $newWrapper = $parent.find('.grocery-crud-wrapper');
                    populateColumnsAndFilters($newWrapper);
                    initInlineEditing($newWrapper);

                    // Restore hidden columns state (user unchecked some checkboxes before refresh)
                    if (hiddenColumns.length) {
                        hiddenColumns.forEach(function (col) {
                            $newWrapper.find('.gc-columns-menu input[data-column="' + col + '"]')
                                .prop('checked', false)
                                .trigger('change');
                        });
                    }

                    // Restore saved column order from localStorage
                    try {
                        var url = window.location.href;
                        var raw = localStorage.getItem('gc_settings_' + btoa(url));
                        if (raw) {
                            var settings = JSON.parse(raw);
                            if (settings.columnOrder && settings.columnOrder.length) {
                                applyColumnOrder($newWrapper, settings.columnOrder);
                            }
                        }
                    } catch (e) {}
                    // Initialize table-dragger on the refreshed table
                    initTableDragger($newWrapper);

                    // Restore advanced filter panel items and visibility
                    if (advancedFilters && advancedFilters.length) {
                        var $panel = $newWrapper.find('.gc-filter-panel');
                        var $rows = $panel.find('.gc-filter-rows');
                        var $template = $rows.find('.gc-filter-item-template');

                        advancedFilters.forEach(function (f) {
                            var $item = $template.clone()
                                .removeClass('gc-filter-item-template')
                                .addClass('gc-filter-item')
                                .show();
                            $item.find('.gc-filter-col').val(f.field);
                            $item.find('.gc-filter-op').val(f.operator);
                            $item.find('.gc-filter-val').val(f.value);
                            $rows.append($item);
                        });

                        $panel.show();
                    }
                } else {
                    showAlert(response.message || 'Failed to load data.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred while loading data.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    function loadAddForm($btn) {
        var $wrapper = $btn.closest('.grocery-crud-wrapper');

        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'GET',
            data: { gc_action: 'add_form' },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    var $modal = GcModal.show(response.html);
                    bindFormEvents($modal);
                } else {
                    showAlert(response.message || 'Failed to load form.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    function loadEditForm($btn) {
        var $wrapper = $btn.closest('.grocery-crud-wrapper');
        var id = $btn.data('id');

        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'GET',
            data: { gc_action: 'edit_form', id: id },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    var $modal = GcModal.show(response.html);
                    bindFormEvents($modal);
                } else {
                    showAlert(response.message || 'Failed to load form.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    // ======== Columns & Filter Populate ========
    function populateColumnsAndFilters($wrapper) {
        // Columns menu: populate checkboxes from table headers
        var $menu = $wrapper.find('.gc-columns-menu');
        if ($menu.length) {
            $menu.empty();
            $wrapper.find('.gc-table th[data-column]').each(function () {
                var col = $(this).data('column');
                var label = $(this).data('label') || col;
                var isHidden = $(this).hasClass('d-none');
                var $cb = $('<div class="form-check" draggable="true">'
                    + '<input type="checkbox" class="form-check-input" id="col_'
                    + col + '" data-column="' + col + '"' + (isHidden ? '' : ' checked') + '>'
                    + '<label class="form-check-label" for="col_' + col + '">'
                    + $('<span>').text(label).html()
                    + '</label></div>');
                $menu.append($cb);
            });
        }

        // Filter column selects: populate options from table headers
        $wrapper.find('.gc-filter-col').each(function () {
            var $select = $(this);
            var currentVal = $select.val();
            // Only populate if empty (template only has the placeholder option)
            if ($select.find('option[value]').length <= 1) {
                $wrapper.find('.gc-table th[data-column]').each(function () {
                    var col = $(this).data('column');
                    var label = $(this).data('label') || col;
                    $select.append('<option value="' + col + '">' + $('<span>').text(label).html() + '</option>');
                });
                if (currentVal) $select.val(currentVal);
            }
        });
    }

    /**
     * Reorder table columns and columns menu to match saved order.
     */
    function applyColumnOrder($wrapper, columnOrder) {
        if (!columnOrder || !columnOrder.length) return;

        // 1. Reorder columns menu checkboxes
        var $menu = $wrapper.find('.gc-columns-menu');
        if ($menu.length) {
            var items = [];
            $menu.find('.form-check').each(function () {
                var col = $(this).find('.form-check-input').data('column');
                items.push({ col: col, $el: $(this) });
            });
            items.sort(function (a, b) {
                var ia = columnOrder.indexOf(a.col);
                var ib = columnOrder.indexOf(b.col);
                if (ia === -1) ia = 999;
                if (ib === -1) ib = 999;
                return ia - ib;
            });
            // Detach and re-append in sorted order
            $menu.find('.form-check').detach();
            items.forEach(function (item) {
                $menu.append(item.$el);
            });
        }

        // 2. Reorder table columns
        var $table = $wrapper.find('.gc-table');
        if (!$table.length) return;

        $table.find('thead tr, tbody tr').each(function () {
            var $row = $(this);
            var $dataCells = $row.find('[data-column]');
            if ($dataCells.length < 2) return;

            // Collect cells in an array
            var cells = [];
            $dataCells.each(function () {
                cells.push({ col: $(this).data('column'), $el: $(this) });
            });

            // Sort by columnOrder
            cells.sort(function (a, b) {
                var ia = columnOrder.indexOf(a.col);
                var ib = columnOrder.indexOf(b.col);
                if (ia === -1) ia = 999;
                if (ib === -1) ib = 999;
                return ia - ib;
            });

            // Find reference: element just before the first data-cell
            var $firstDataCell = $dataCells.first();
            var $prev = $firstDataCell.prev();
            var hasPrev = $prev.length > 0;

            // Detach all data cells
            $dataCells.detach();

            // Insert sorted cells after prev (or at start of row)
            var sortedEls = cells.map(function (c) { return c.$el[0]; });
            if (hasPrev) {
                $prev.after(sortedEls);
            } else {
                $row.prepend(sortedEls);
            }
        });

        // Restore d-none visibility on any columns that were hidden
        if ($wrapper.find('.gc-columns-menu').length) {
            $wrapper.find('.gc-columns-menu input[type="checkbox"]').each(function () {
                var col = $(this).data('column');
                if (!$(this).is(':checked')) {
                    $table.find('th[data-column="' + col + '"], td[data-column="' + col + '"]').addClass('d-none');
                }
            });
        }
    }

    /**
     * Save current column order from the columns menu to localStorage.
     */
    function saveColumnOrder($wrapper) {
        var menu = $wrapper.find('.gc-columns-menu');
        if (!menu.length) return;
        var order = [];
        menu.find('.form-check-input').each(function () {
            order.push($(this).data('column'));
        });
        var url = window.location.href;
        try {
            var key = 'gc_settings_' + btoa(url);
            var raw = localStorage.getItem(key);
            var settings = raw ? JSON.parse(raw) : { columns: {}, filters: [] };
            settings.columnOrder = order;
            localStorage.setItem(key, JSON.stringify(settings));
        } catch (e) {}
    }

    /**
     * Initialize table-dragger on all tables inside the given wrapper.
     * Uses .gc-drag-handle inside headers so sorting (click on header text)
     * and dragging (click on handle) don't conflict.
     */
    function initTableDragger($wrapper) {
        console.log('[GC_TD] initTableDragger called, tableDragger=',
            typeof tableDragger, 'wrapper=', $wrapper.length);
        // table-dragger via CDN is UMD: actual function is .default
        var draggerFn = (tableDragger && tableDragger.default) || tableDragger;
        if (typeof draggerFn !== 'function') {
            console.warn('[GC_TD] tableDragger not available, obj=', tableDragger);
            return;
        }
        // Destroy any previous instance on this wrapper
        var prev = $wrapper.data('gcDragger');
        if (prev) { try { prev.destroy(); } catch(e) {} }
        var $table = $wrapper.find('.gc-table');
        console.log('[GC_TD] table found:', $table.length);
        if (!$table.length) return;
        try {
            // Add drag handle to each data-column header in the first header row
            var $handles = $table.find('thead tr:first-child th[data-column]');
            console.log('[GC_TD] data-column headers:', $handles.length);
            if ($handles.length < 2) {
                console.warn('[GC_TD] not enough draggable columns');
            }
            $handles.each(function () {
                if (!$(this).find('.gc-drag-handle').length) {
                    $('<span class="gc-drag-handle">⠿</span> ').prependTo(this);
                }
            });
            var handleCount = $table.find('.gc-drag-handle').length;
            console.log('[GC_TD] handles added:', handleCount);
            var dragger = draggerFn($table[0], {
                mode: 'column',
                dragHandler: '.gc-drag-handle',
                animation: 200
            });
            $wrapper.data('gcDragger', dragger);
            console.log('[GC_TD] table-dragger initialized');
            dragger.on('drop', function (oldIndex, newIndex, el, mode) {
                console.log('[GC_TD] drop event', oldIndex, newIndex, mode);
                // table-dragger already reordered table DOM
                // Read new column order from table headers
                var newOrder = [];
                $table[0].querySelectorAll('thead th[data-column]').forEach(function (th) {
                    newOrder.push(th.getAttribute('data-column'));
                });
                if (!newOrder.length) return;
                // Sync columns menu order to match
                var $menu = $wrapper.find('.gc-columns-menu');
                if ($menu.length) {
                    var sorted = [];
                    newOrder.forEach(function (col) {
                        var $item = $menu.find('.form-check-input[data-column="' + col + '"]').closest('.form-check');
                        if ($item.length) sorted.push($item[0]);
                    });
                    // Append any remaining items at end
                    $menu.find('.form-check').each(function () {
                        if (sorted.indexOf(this) === -1) sorted.push(this);
                    });
                    $menu.find('.form-check').detach();
                    sorted.forEach(function (el) { $menu.append(el); });
                }
                // Save order
                saveColumnOrder($wrapper);
            });
        } catch (e) {
            console.warn('[GC] table-dragger init failed:', e);
        }
    }

    function submitForm($form) {
        var $modal = $form.closest('.modal');
        var $submitBtn = $form.find('button[type="submit"]');
        var mode = $form.data('mode');
        var hasFile = $form.find('input[type="file"]').length > 0;

        // Disable button
        $submitBtn.prop('disabled', true).addClass('btn-gc-loading');

        syncRichtextEditors($modal);

        var ajaxConfig = {
            url: window.location.href,
            method: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    GcModal.hide();
                    showAlert(response.message, 'success');
                    // Refresh the list
                    refreshList($('.grocery-crud-wrapper'));
                } else {
                    // Show validation errors
                    if (response.errors) {
                        // Clear previous errors
                        $form.find('.has-error').removeClass('has-error');
                        $form.find('.invalid-feedback').remove();

                        $.each(response.errors, function (field, message) {
                            var $field = $form.find('[name="' + field + '"], [name="' + field + '[]"]').first();
                            var $group = $field.closest('.mb-3');
                            $group.addClass('has-error');
                            $group.append('<div class="invalid-feedback d-block">' + message + '</div>');
                        });
                    }
                    showAlert(response.message || 'Operation failed.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                $submitBtn.prop('disabled', false).removeClass('btn-gc-loading');
            }
        };

        if (hasFile) {
            ajaxConfig.data = buildFormData($form);
            ajaxConfig.processData = false;
            ajaxConfig.contentType = false;
        } else {
            // $form.serialize() skips disabled inputs AND unchecked checkboxes.
            // We need to ensure unchecked checkboxes are sent as '0'.
            var formData = $form.serialize();
            $form.find('input[type="checkbox"]:not(:checked)').each(function () {
                var $cb = $(this);
                var name = $cb.attr('name');
                // Skip array fields (e.g., tags[]) — they're only meaningful when checked
                if (name.indexOf('[]') !== -1) return;
                // Only add if not already serialized (e.g., via a hidden sibling)
                if (formData.indexOf(name + '=') === -1) {
                    formData += '&' + name + '=0';
                }
            });
            ajaxConfig.data = formData + '&gc_action=' + mode;
        }

        $.ajax(ajaxConfig);
    }

    function restoreRecord($btn) {
        var $wrapper = $btn.closest('.grocery-crud-wrapper');
        var id = $btn.data('id');

        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'POST',
            data: { gc_action: 'restore', id: id },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    showAlert(response.message, 'success');
                    refreshList($wrapper);
                } else {
                    showAlert(response.message || 'Failed to restore record.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    function loadTrashList($btn) {
        var $wrapper = $btn.closest('.grocery-crud-wrapper');

        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'GET',
            data: { gc_action: 'trash_list' },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    $wrapper.replaceWith(response.html);
                    bindEvents();
                } else {
                    showAlert(response.message || 'Failed to load trash.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    function deleteRecord($btn) {
        var $wrapper = $btn.closest('.grocery-crud-wrapper');
        var id = $btn.data('id');
        var message = $wrapper.data('confirm-delete') || 'Are you sure you want to delete this record?';

        if (!confirm(message)) {
            return;
        }

        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'POST',
            data: { gc_action: 'delete', id: id },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    showAlert(response.message, 'success');
                    refreshList($wrapper);
                } else {
                    showAlert(response.message || 'Failed to delete record.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    function loadSubGrid($btn) {
        var $wrapper = $btn.closest('.grocery-crud-wrapper');
        var $row = $btn.closest('tr');
        var $subRow = $row.next('.gc-subgrid-row');
        var subGridField = $btn.data('subgrid');
        var parentId = $btn.data('parent-id');

        if ($subRow.length === 0) return;

        // If already loaded, just toggle
        var $content = $subRow.find('.gc-subgrid-content');
        var $table = $content.find('.gc-subgrid-inner');
        if ($table.length > 0) {
            $subRow.toggle();
            $btn.find('i').toggleClass('bi-chevron-right bi-chevron-down');
            return;
        }

        // Load via AJAX
        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'GET',
            data: {
                gc_action: 'sub_grid',
                sub_grid: subGridField,
                parent_id: parentId
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    $content.html(response.html);
                    $subRow.show();
                    $btn.find('i').removeClass('bi-chevron-right').addClass('bi-chevron-down');
                } else {
                    showAlert(response.message || 'Failed to load sub-grid.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred loading sub-grid.', 'danger');
            },
            complete: function () {
                hideLoading();
            }
        });
    }

    function handleExport($btn, format) {
        if (format === 'print') {
            // Print view: open in new window
            window.open(
                window.location.pathname + '?gc_action=print_view',
                '_blank',
                'width=1200,height=800,scrollbars=yes'
            );
        } else {
            // CSV, Excel, PDF: download normally
            showLoading();
            window.location.href = window.location.pathname
                + '?gc_action=export&format=' + format;
            setTimeout(function () {
                hideLoading();
            }, 2000);
        }
    }

    // ======== Import Workflow ========
    var _importing = false;

    function loadImportForm($btn) {
        if (_importing) return;
        _importing = true;
        showLoading();
        $.ajax({
            url: window.location.href,
            method: 'GET',
            data: { gc_action: 'import_form' },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    var $modal = GcModal.show(response.html);
                    bindImportEvents($modal);
                } else {
                    showAlert(response.message || 'Failed to load import form.', 'danger');
                }
            },
            error: function () {
                showAlert('An error occurred.', 'danger');
            },
            complete: function () {
                hideLoading();
                _importing = false;
            }
        });
    }

    function bindImportEvents($modal) {
        // Close button
        $modal.on('click', '.gc-form-close', function (e) {
            e.preventDefault();
            GcModal.hide();
        });

        // Close on backdrop click
        $modal.on('hidden.bs.modal', function () {
            GcModal.remove();
        });

        // Browse button -> trigger file input
        $modal.on('click', '.gc-import-browse-btn', function () {
            $modal.find('.gc-import-file-input').click();
        });

        // Click on dropzone -> trigger file input (skip if click originated from the file input itself)
        $modal.on('click', '.gc-import-dropzone', function (e) {
            if ($(e.target).closest('.gc-import-file-input, .gc-import-browse-btn').length) return;
            $modal.find('.gc-import-file-input').click();
        });

        // File selected -> upload
        $modal.on('change', '.gc-import-file-input', function () {
            var file = this.files[0];
            if (!file) return;

            // Show filename
            $modal.find('.gc-import-filename').text(file.name).removeClass('d-none');

            // Upload
            uploadImportFile($modal, file);
        });

        // Execute import
        $modal.on('click', '.gc-import-execute-btn', function () {
            executeImport($modal);
        });

        // Download template with selected fields
        $modal.on('click', '.gc-template-download-selected', function () {
            var fields = [];
            $modal.find('.gc-template-field-cb:checked').each(function () {
                fields.push($(this).val());
            });
            if (fields.length === 0) {
                showAlert('Please select at least one field.', 'warning');
                return;
            }
            var baseUrl = window.location.href.split('?')[0];
            var params = $.param({ gc_action: 'import_template', fields: fields });
            window.open(baseUrl + '?' + params, '_blank');
        });
    }

    function uploadImportFile($modal, file) {
        var formData = new FormData();
        formData.append('import_file', file);
        formData.append('gc_action', 'import_upload');

        // Show uploading state
        $modal.find('.gc-import-dropzone').addClass('d-none');
        $modal.find('.gc-import-filename').addClass('d-none');
        $modal.find('.gc-import-uploading').removeClass('d-none');

        $.ajax({
            url: window.location.href,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function (response) {
                $modal.find('.gc-import-uploading').addClass('d-none');
                $modal.find('.gc-import-dropzone').removeClass('d-none');

                if (response.success) {
                    showMappingUI($modal, response);
                } else {
                    showAlert(response.message || 'Failed to parse file.', 'danger');
                }
            },
            error: function () {
                $modal.find('.gc-import-uploading').addClass('d-none');
                $modal.find('.gc-import-dropzone').removeClass('d-none');
                showAlert('An error occurred while uploading.', 'danger');
            }
        });
    }

    function showMappingUI($modal, data) {
        var headers = data.headers || [];
        var preview = data.preview || [];
        var mapping = data.mapping || [];
        var fields = data.fields || [];
        var fieldLabels = data.fieldLabels || {};
        var totalRows = data.totalRows || 0;

        // Build mapping table
        var $mappingBody = $modal.find('.gc-import-mapping-table tbody');
        $mappingBody.empty();

        headers.forEach(function (header, index) {
            var mappedField = mapping[index] || '';
            var sampleData = preview.length > 0 ? (preview[0][header] || '') : '';
            var $row = $('<tr></tr>');
            $row.append('<td><strong>' + $('<span>').text(header).html() + '</strong></td>');

            var $select = $('<select class="form-select form-select-sm"></select>');
            $select.append('<option value="">-- ' + $('<span>').text(data.lang_not_mapped || 'Not mapped').html() + ' --</option>');

            fields.forEach(function (field) {
                var label = fieldLabels[field] || field;
                var $opt = $('<option></option>').attr('value', field).text(label);
                if (field === mappedField) {
                    $opt.prop('selected', true);
                }
                $select.append($opt);
            });

            var $td = $('<td></td>').append($select);
            $row.append($td);
            $row.append('<td><code class="small">' + $('<span>').text(sampleData).html() + '</code></td>');
            $mappingBody.append($row);
        });

        // Build preview table
        var $previewHead = $modal.find('.gc-import-preview-table thead tr');
        var $previewBody = $modal.find('.gc-import-preview-table tbody');
        $previewHead.empty();
        $previewBody.empty();

        headers.forEach(function (header) {
            $previewHead.append('<th>' + $('<span>').text(header).html() + '</th>');
        });

        preview.forEach(function (row) {
            var $row = $('<tr></tr>');
            headers.forEach(function (header) {
                $row.append('<td class="small">' + $('<span>').text(row[header] || '').html() + '</td>');
            });
            $previewBody.append($row);
        });

        // Show total rows
        $modal.find('.gc-import-preview-info').text(data.total_rows_label || 'Total rows in file') + ': ' + totalRows;
        $modal.find('.gc-import-preview-info').html(
            '<span class="text-muted">' + (data.total_rows_label || 'Total rows in file') + ': <strong>' + totalRows + '</strong></span>'
        );

        // Show execute button
        $modal.find('.gc-import-execute-btn').removeClass('d-none');

        // Show mapping step
        $modal.find('.gc-import-step[data-step="mapping"]').removeClass('d-none');

        // Store file data for later
        $modal.data('importData', {
            totalRows: totalRows,
            preview: preview,
            headers: headers,
            mapping: mapping
        });
    }

    function executeImport($modal) {
        var importData = $modal.data('importData');
        if (!importData) return;

        // Read current mapping from UI
        var mapping = [];
        $modal.find('.gc-import-mapping-table tbody tr').each(function () {
            var $select = $(this).find('select');
            mapping.push($select.val() || null);
        });

        var totalRows = importData.totalRows || 0;
        var msg = (importData.confirm_label || 'Are you sure you want to import {total} records?').replace('{total}', totalRows);
        if (!confirm(msg)) return;

        // Get preview data as rows (header-indexed arrays)
        var rows = importData.preview.map(function (row) {
            return importData.headers.map(function (header) {
                return row[header] || '';
            });
        });

        // Disable button
        var $btn = $modal.find('.gc-import-execute-btn');
        $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Importing...');

        $.ajax({
            url: window.location.href,
            method: 'POST',
            data: {
                gc_action: 'import_execute',
                rows: JSON.stringify(rows),
                mapping: JSON.stringify(mapping)
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    GcModal.hide();
                    var message = response.message || 'Import completed.';
                    if (response.errors && response.errors.length > 0) {
                        message += ' (' + response.errors.length + ' errors)';
                    }
                    showAlert(message, response.imported > 0 ? 'success' : 'danger');
                    refreshList($('.grocery-crud-wrapper'));
                } else {
                    showAlert(response.message || 'Import failed.', 'danger');
                    $btn.prop('disabled', false).text('Import Data');
                }
            },
            error: function () {
                showAlert('An error occurred during import.', 'danger');
                $btn.prop('disabled', false).text('Import Data');
            }
        });
    }

    // ======== Event Binding ========
    function bindEvents() {
        // Import button
        $(document).off('click', '.btn-gc-import').on('click', '.btn-gc-import', function (e) {
            e.preventDefault();
            loadImportForm($(this));
        });

        // Add button
        $(document).off('click', '.btn-gc-add').on('click', '.btn-gc-add', function (e) {
            e.preventDefault();
            loadAddForm($(this));
        });

        // Edit button
        $(document).off('click', '.btn-gc-edit').on('click', '.btn-gc-edit', function (e) {
            e.preventDefault();
            loadEditForm($(this));
        });

        // Delete button
        $(document).off('click', '.btn-gc-delete').on('click', '.btn-gc-delete', function (e) {
            e.preventDefault();
            deleteRecord($(this));
        });

        // Restore button (trashed view)
        $(document).off('click', '.btn-gc-restore').on('click', '.btn-gc-restore', function (e) {
            e.preventDefault();
            restoreRecord($(this));
        });

        // Trash list button
        $(document).off('click', '.gc-btn-trash').on('click', '.gc-btn-trash', function (e) {
            e.preventDefault();
            loadTrashList($(this));
        });

        // Active list button (from trashed view)
        $(document).off('click', '.gc-btn-active').on('click', '.gc-btn-active', function (e) {
            e.preventDefault();
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        });

        // Sub-grid expand/collapse toggle
        $(document).off('click', '.gc-subgrid-toggle').on('click', '.gc-subgrid-toggle', function (e) {
            e.preventDefault();
            loadSubGrid($(this));
        });

        // Pagination links
        $(document).off('click', '.gc-page-link').on('click', '.gc-page-link', function (e) {
            e.preventDefault();
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var page = $(this).data('page');
            $wrapper.data('currentPage', page);
            refreshList($wrapper);
        });

        // Search - realtime on keyup (debounced)
        $(document).off('keyup', '.gc-search-input').on('keyup', '.gc-search-input', $.debounce(function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        }, 400));

        // Search - immediate on Enter key
        $(document).off('keydown', '.gc-search-input').on('keydown', '.gc-search-input', function (e) {
            if (e.keyCode === 13) {
                e.preventDefault();
                var $wrapper = $(this).closest('.grocery-crud-wrapper');
                $wrapper.data('currentPage', 1);
                refreshList($wrapper);
            }
        });

        // Show/hide clear search button on input change
        $(document).off('input', '.gc-search-input').on('input', '.gc-search-input', function () {
            var $clearBtn = $(this).closest('.input-group').find('.gc-search-clear');
            if ($(this).val()) {
                $clearBtn.show();
            } else {
                $clearBtn.hide();
            }
        });

        // Clear search button
        $(document).off('click', '.gc-search-clear').on('click', '.gc-search-clear', function (e) {
            e.preventDefault();
            var $input = $(this).closest('.input-group').find('.gc-search-input');
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            $input.val('');
            $(this).hide();
            $input.focus();
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        });

        // ======== Column Filters ========
        var filterTimer = null;
        $(document).off('change', '.gc-column-filter').on('change', '.gc-column-filter', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        });
        $(document).off('input', '.gc-column-filter').on('input', '.gc-column-filter', function () {
            var $self = $(this);
            // Only debounce text inputs (selects use 'change' above)
            if ($self.is('select')) return;
            clearTimeout(filterTimer);
            filterTimer = setTimeout(function () {
                var $wrapper = $self.closest('.grocery-crud-wrapper');
                $wrapper.data('currentPage', 1);
                refreshList($wrapper);
            }, 400);
        });

        // ======== Batch Actions ========
        // Select-all checkbox
        $(document).off('change', '.gc-select-all').on('change', '.gc-select-all', function () {
            var isChecked = $(this).prop('checked');
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            $wrapper.find('.gc-row-checkbox').prop('checked', isChecked);
            updateBatchToolbar($wrapper);
        });

        // Row checkbox
        $(document).off('change', '.gc-row-checkbox').on('change', '.gc-row-checkbox', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var allChecked = $wrapper.find('.gc-row-checkbox').length === $wrapper.find('.gc-row-checkbox:checked').length;
            $wrapper.find('.gc-select-all').prop('checked', allChecked);
            updateBatchToolbar($wrapper);
        });

        // Batch action button
        $(document).off('click', '.gc-batch-action').on('click', '.gc-batch-action', function (e) {
            e.preventDefault();
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var actionId = $(this).data('batch-action');
            var selectedIds = [];
            $wrapper.find('.gc-row-checkbox:checked').each(function () {
                selectedIds.push($(this).val());
            });
            if (selectedIds.length === 0) return;

            // Detect if we're in trash view (the "Active Records" button only appears there)
            var isTrashView = $wrapper.find('.gc-btn-active').length > 0;

            if (actionId === 'delete_selected') {
                var msg = isTrashView
                    ? 'Are you sure you want to permanently delete ' + selectedIds.length + ' selected record(s)? This cannot be undone.'
                    : 'Are you sure you want to delete ' + selectedIds.length + ' selected record(s)?';
                if (!confirm(msg)) {
                    return;
                }
            }

            showLoading();

            var requestData = {
                gc_action: 'batch_action',
                batch_action: actionId,
                ids: selectedIds
            };

            // When in trash view, delete_selected should permanently delete
            if (isTrashView && actionId === 'delete_selected') {
                requestData.permanent_delete = 1;
            }

            $.ajax({
                url: window.location.href,
                method: 'POST',
                data: requestData,
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        showAlert(response.message || 'Action completed.', 'success');
                        refreshList($wrapper);
                    } else {
                        showAlert(response.message || 'Action failed.', 'danger');
                        hideLoading();
                    }
                },
                error: function () {
                    showAlert('An error occurred.', 'danger');
                    hideLoading();
                }
            });
        });

        // Batch toolbar helper
        function updateBatchToolbar($wrapper) {
            var $toolbar = $wrapper.find('.gc-batch-toolbar');
            var $num = $toolbar.find('.gc-selected-num');
            var count = $wrapper.find('.gc-row-checkbox:checked').length;
            if (count > 0) {
                $toolbar.show();
                $num.text(count);
            } else {
                $toolbar.hide();
            }
        }

        // Sortable column headers
        $(document).off('click', '.gc-sortable').on('click', '.gc-sortable', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var field = $(this).data('sort-field');
            var dir = $(this).data('sort-dir');
            $wrapper.data('sortField', field);
            $wrapper.data('sortDir', dir);
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        });

        // Export
        $(document).off('click', '[data-export]').on('click', '[data-export]', function (e) {
            e.preventDefault();
            handleExport($(this), $(this).data('export'));
        });

        // ======== Columns Dropdown Toggle ========
        $(document).off('change', '.gc-columns-menu input[type="checkbox"]').on('change', '.gc-columns-menu input[type="checkbox"]', function () {
            var col = $(this).data('column');
            var $table = $(this).closest('.grocery-crud-wrapper').find('.gc-table');
            if ($(this).is(':checked')) {
                $table.find('th[data-column="' + col + '"], td[data-column="' + col + '"]').removeClass('d-none');
            } else {
                $table.find('th[data-column="' + col + '"], td[data-column="' + col + '"]').addClass('d-none');
            }
        });

        // ======== Filter Panel ========
        // Toggle filter panel
        $(document).off('click', '.gc-filter-btn').on('click', '.gc-filter-btn', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var $panel = $wrapper.find('.gc-filter-panel');
            $panel.toggle();
        });

        // Add filter row
        $(document).off('click', '.gc-filter-add').on('click', '.gc-filter-add', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var $rows = $wrapper.find('.gc-filter-rows');
            var $template = $rows.find('.gc-filter-item-template').clone().removeClass('gc-filter-item-template').addClass('gc-filter-item').show();
            $template.find('input').val('');
            $template.find('select').prop('selectedIndex', 0);
            $rows.append($template);
        });

        // Remove filter row
        $(document).off('click', '.gc-filter-item-remove').on('click', '.gc-filter-item-remove', function () {
            $(this).closest('.gc-filter-item').remove();
        });

        // Apply filters
        $(document).off('click', '.gc-filter-apply').on('click', '.gc-filter-apply', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var filters = [];
            $wrapper.find('.gc-filter-item').each(function () {
                var col = $(this).find('.gc-filter-col').val();
                var op = $(this).find('.gc-filter-op').val();
                var val = $(this).find('.gc-filter-val').val();
                if (col && val) {
                    filters.push({field: col, operator: op, value: val});
                }
            });
            $wrapper.data('gcAdvancedFilters', filters);
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        });

        // Clear filters
        $(document).off('click', '.gc-filter-clear').on('click', '.gc-filter-clear', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            $wrapper.find('.gc-filter-item').remove();
            $wrapper.find('.gc-filter-panel').hide();
            $wrapper.removeData('gcAdvancedFilters');
            $wrapper.data('currentPage', 1);
            refreshList($wrapper);
        });

        // ======== Column Reorder via table-dragger ========
        // Since input/label have pointer-events:none, handle toggle via click on the .form-check div
        $(document).off('click', '.gc-columns-menu .form-check').on('click', '.gc-columns-menu .form-check', function () {
            var $input = $(this).find('.form-check-input');
            $input.prop('checked', !$input.is(':checked')).trigger('change');
        });

        // ======== Settings Save/Load/Reset ========
        // Save settings
        $(document).off('click', '.gc-settings-save').on('click', '.gc-settings-save', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var url = window.location.href;
            var settings = {
                columns: {},
                columnOrder: [],
                filters: $wrapper.data('gcAdvancedFilters') || []
            };
            $wrapper.find('.gc-columns-menu input[type="checkbox"]').each(function () {
                settings.columns[$(this).data('column')] = $(this).is(':checked');
                settings.columnOrder.push($(this).data('column'));
            });
            try {
                localStorage.setItem('gc_settings_' + btoa(url), JSON.stringify(settings));
                showAlert('Settings saved.', 'success');
            } catch (e) {
                showAlert('Could not save settings.', 'danger');
            }
        });

        // Load settings
        $(document).off('click', '.gc-settings-load').on('click', '.gc-settings-load', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var url = window.location.href;
            try {
                var raw = localStorage.getItem('gc_settings_' + btoa(url));
                if (!raw) { showAlert('No saved settings found.', 'warning'); return; }
                var settings = JSON.parse(raw);
                // Restore column order
                if (settings.columnOrder && settings.columnOrder.length) {
                    applyColumnOrder($wrapper, settings.columnOrder);
                }
                // Restore column visibility
                if (settings.columns) {
                    $wrapper.find('.gc-columns-menu input[type="checkbox"]').each(function () {
                        var col = $(this).data('column');
                        if (settings.columns[col] !== undefined) {
                            $(this).prop('checked', settings.columns[col]).trigger('change');
                        }
                    });
                }
                // Restore filters
                if (settings.filters && settings.filters.length) {
                    $wrapper.data('gcAdvancedFilters', settings.filters);
                    refreshList($wrapper);
                }
                showAlert('Settings loaded.', 'success');
            } catch (e) {
                showAlert('Could not load settings.', 'danger');
            }
        });

        // Reset settings
        $(document).off('click', '.gc-settings-reset').on('click', '.gc-settings-reset', function () {
            var $wrapper = $(this).closest('.grocery-crud-wrapper');
            var url = window.location.href;
            try {
                localStorage.removeItem('gc_settings_' + btoa(url));
                // Reset column order to original (from table headers)
                var order = [];
                $wrapper.find('.gc-table th[data-column]').each(function () {
                    order.push($(this).data('column'));
                });
                if (order.length) {
                    applyColumnOrder($wrapper, order);
                }
                $wrapper.find('.gc-columns-menu input[type="checkbox"]').each(function () {
                    $(this).prop('checked', true).trigger('change');
                });
                $wrapper.removeData('gcAdvancedFilters');
                $wrapper.find('.gc-filter-item').remove();
                $wrapper.find('.gc-filter-panel').hide();
                showAlert('Settings reset to defaults.', 'success');
            } catch (e) {}
        });

        // Image viewer - click thumbnail to show enlarged
        $(document).off('click', '.gc-table img.gc-thumb').on('click', '.gc-table img.gc-thumb', function () {
            var $img = $(this);
            var src = $img.attr('src') || $img.data('src');
            if (!src) return;

            var modalHtml = '<div class="modal fade gc-image-viewer" tabindex="-1">'
                + '<div class="modal-dialog modal-dialog-centered">'
                + '<div class="modal-content">'
                + '<div class="modal-header border-0 pb-0">'
                + '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>'
                + '</div>'
                + '<div class="modal-body">'
                + '<img src="' + src + '" alt="" style="display:none">'
                + '</div>'
                + '</div>'
                + '</div>'
                + '</div>';

            var $modal = $(modalHtml);
            var $modalImg = $modal.find('img');
            $('body').append($modal);
            $modal.modal('show');

            // Adjust dialog to image natural size after load
            $modalImg.on('load', function () {
                var $dialog = $modal.find('.modal-dialog');
                var imgW = this.naturalWidth;
                var imgH = this.naturalHeight;

                // Cap at viewport - some margin
                var maxW = window.innerWidth * 0.9;
                var maxH = window.innerHeight * 0.85;

                if (imgW > maxW || imgH > maxH) {
                    // Image bigger than viewport — let CSS handle it
                    $modalImg.show();
                } else {
                    // Image fits — size dialog to image
                    $modalImg.css({display:'block', width: imgW + 'px', height: 'auto'});
                    $dialog.css('max-width', (imgW + 40) + 'px');
                }

                // Re-center modal after content resize
                $modal[0]._isShown && $modal.modal('handleUpdate');
            });

            // If already cached, trigger load manually
            if ($modalImg[0].complete) {
                $modalImg.trigger('load');
            } else {
                // Ensure img is shown even if load fails
                $modalImg.on('error', function () {
                    $modalImg.show();
                });
            }

            $modal.on('hidden.bs.modal', function () {
                $modal.remove();
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open');
            });
        });

        // ======== Repeater Fields ========
        // Add item
        $(document).off('click', '.gc-repeater-add').on('click', '.gc-repeater-add', function () {
            var $btn = $(this);
            var $container = $btn.closest('.gc-repeater-container');
            var $template = $container.find('.gc-repeater-template');
            var index = $container.find('.gc-repeater-item').not($container.find('.gc-repeater-template .gc-repeater-item')).length;

            var html = $template.html().replace(/__INDEX__/g, index);
            html = html.replace(/ disabled/g, '');  // Remove disabled from cloned items
            $btn.before(html);
        });

        // Remove item
        $(document).off('click', '.gc-repeater-remove').on('click', '.gc-repeater-remove', function () {
            $(this).closest('.gc-repeater-item').remove();
        });

        // Populate columns menu and filter selects for existing wrappers
        $(document).find('.grocery-crud-wrapper').each(function () {
            populateColumnsAndFilters($(this));
            initInlineEditing($(this));
        });

        // GC toolbar dropdown: bypass any framework-native dropdown system (Materialize, Bootstrap, etc.)
        // Destroy Materialize instances on GC toolbar buttons first (Materialize auto-inits on DOMContentLoaded
        // and its click handler uses stopPropagation, blocking GC's document-level handlers)
        if (typeof M !== 'undefined' && typeof M.Dropdown !== 'undefined') {
            $('.grocery-crud-wrapper .dropdown-trigger').each(function () {
                var instance = M.Dropdown.getInstance(this);
                if (instance) {
                    instance.destroy();
                }
            });
        }

        // Initialize all GC dropdowns as hidden (e.g. Materialize CSS doesn't hide .dropdown-content)
        $('.grocery-crud-wrapper .dropdown-content').hide();

        // Direct click handler for each dropdown trigger (binds directly to elements, avoids delegation issues)
        $('.grocery-crud-wrapper a.dropdown-trigger[data-target]').off('click.gc-dd').on('click.gc-dd', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn = $(this);
            var targetId = $btn.data('target');
            var $target = $('#' + targetId);
            if (!$target.length) return;

            // Debounce: ignore if this dropdown was just interacted with (prevents double-fire)
            var now = Date.now();
            var lastToggle = $target.data('gc-last-toggle') || 0;
            if (now - lastToggle < 100) {
                $target.data('gc-last-toggle', now);
                return;
            }
            $target.data('gc-last-toggle', now);

            // If this target is already open, close it
            if ($target.is(':visible')) {
                $target.hide();
                return;
            }

            // Close all other dropdowns in this wrapper
            var $wrapper = $btn.closest('.grocery-crud-wrapper');
            $wrapper.find('.dropdown-content').not($target).hide();

            // Show the target with positioning
            var el = $target[0];
            el.style.display = 'block';
            el.style.position = 'absolute';
            el.style.top = '100%';
            el.style.right = '0';
            el.style.zIndex = 1000;
            el.style.marginTop = '4px';
        });

        // Close dropdowns on outside click (delegation is safe for document-level)
        $(document).off('click.gc-dd-close').on('click.gc-dd-close', function (e) {
            if (!$(e.target).closest('.grocery-crud-wrapper a.dropdown-trigger[data-target]').length
                && !$(e.target).closest('.grocery-crud-wrapper .dropdown-content:visible').length) {
                $('.grocery-crud-wrapper .dropdown-content').hide();
            }
        });
    }

    // ======== Dynamic Form Conditions (Depends On) ========
    /**
     * Initialize dependsOn dynamic field visibility/enablement.
     * Fields with data-depends-on attribute will show/hide or enable/disable
     * based on the value of their controlling field.
     */
    function initDependsOn($modal) {
        $modal.find('[data-depends-on]').each(function () {
            var $field = $(this);
            var config = $field.data('dependsOn');
            if (!config) return;

            var $form = $field.closest('.gc-form');
            if (!$form.length) return;

            // Find the controlling field — handle various input types
            var $controller = $form.find('[name="' + config.field + '"]');
            if (!$controller.length) {
                // Try with [] suffix (for checkbox arrays)
                $controller = $form.find('[name="' + config.field + '[]"]');
            }
            if (!$controller.length) return;

            function normalizeConfigValue(val) {
                // Normalize boolean config values to '1'/'0' for checkbox comparison
                // String(true) = 'true' in JS, but checkbox checked = '1'
                if (typeof val === 'boolean') {
                    return val ? '1' : '0';
                }
                return String(val);
            }

            function updateDependsOn() {
                var controllerValue;
                if ($controller.is(':checkbox') || $controller.is('[type="checkbox"]')) {
                    controllerValue = $controller.is(':checked') ? '1' : '0';
                } else {
                    controllerValue = $controller.val();
                }

                var match = String(controllerValue) === normalizeConfigValue(config.value);

                if (config.action === 'enable') {
                    // Enable/disable inputs without hiding
                    $field.find('input, select, textarea, button').prop('disabled', !match);
                    // Visual cue: dim the field when disabled
                    $field.toggleClass('gc-depends-disabled', !match);
                } else {
                    // Default 'show': hide/ show the entire field group
                    $field.toggle(match);
                    // Disable inputs when hidden so they don't submit
                    $field.find('input, select, textarea, button').prop('disabled', !match);
                }
            }

            // Listen for changes on the controller
            $controller.on('change.dependsOn', updateDependsOn);

            // For text inputs, also listen on keyup for immediate feedback
            if ($controller.is('input[type="text"], input[type="number"], input[type="email"], input[type="tel"], input[type="url"], input[type="password"]')) {
                $controller.on('keyup.dependsOn', function () {
                    // Only trigger if value exactly matches or has a substring
                    updateDependsOn();
                });
            }

            // Initial state
            updateDependsOn();
        });
    }

    // Clean up dependsOn listeners when modal is closed
    $(document).on('hidden.bs.modal', '.gc-modal', function () {
        $(this).find('[data-depends-on]').each(function () {
            var config = $(this).data('dependsOn');
            if (!config) return;
            var $form = $(this).closest('.gc-form');
            if ($form.length) {
                $form.find('[name="' + config.field + '"]').off('.dependsOn');
            }
        });
    });

    function bindFormEvents($modal) {
        // Form submission
        $modal.on('submit', '.gc-form', function (e) {
            e.preventDefault();
            submitForm($(this));
        });

        // Close button
        $modal.on('click', '.gc-form-close', function (e) {
            e.preventDefault();
            GcModal.hide();
        });

        // Close on backdrop click
        $modal.on('hidden.bs.modal', function () {
            GcModal.remove();
        });

        // Initialize dependsOn after form is shown
        initDependsOn($modal);

        // Initialize richtext editors
        initRichtextEditors($modal);
    }

    function initRichtextEditors($modal) {
        if (typeof Quill === 'undefined') return;

        $modal.find('.gc-richtext-editor').each(function () {
            // Skip if already initialized (Quill adds ql-container class)
            if ($(this).hasClass('ql-container')) return;

            var quill = new Quill(this, {
                theme: 'snow',
                modules: {
                    toolbar: [
                        ['bold', 'italic', 'underline', 'strike'],
                        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                        [{ 'header': [1, 2, 3, false] }],
                        [{ 'color': [] }, { 'background': [] }],
                        [{ 'align': [] }],
                        ['link', 'clean']
                    ]
                }
            });
        });
    }

    function syncRichtextEditors($modal) {
        $modal.find('.gc-richtext-editor').each(function () {
            var quill = Quill.find(this);
            if (quill) {
                var $editor = $(this);
                var editorId = $editor.attr('id');
                var fieldId = editorId.replace('_editor', '');
                $modal.find('#' + fieldId).val(quill.root.innerHTML);
            }
        });
    }

    // ======== Debounce helper ========
    $.debounce = function (fn, delay) {
        var timer = null;
        return function () {
            var context = this;
            var args = arguments;
            clearTimeout(timer);
            timer = setTimeout(function () {
                fn.apply(context, args);
            }, delay);
        };
    };

    // ======== Inline Editing ========
    /**
     * Initialize inline editing on a wrapper.
     */
    function initInlineEditing($wrapper) {
        if (!$wrapper.find('[data-inline-edit]').length) {
            return;
        }

        // Close any existing active editor
        function closeActiveEditor() {
            var $active = $('.gc-inline-editor-active');
            if ($active.length) {
                $active.removeClass('gc-inline-editor-active');
                var $cell = $active.closest('td');
                $cell.find('.gc-inline-editor').remove();
                $cell.css('padding', '');
            }
        }

        // Save inline edit via AJAX
        function saveInlineEdit($cell, value) {
            var $wrapper = $cell.closest('.grocery-crud-wrapper');
            var id = $cell.closest('tr').data('parent-id');
            if (id === undefined) {
                // Fallback: try to find the PK in the row
                var pk = $wrapper.data('primaryKey') || 'id';
                id = $cell.closest('tr').find('[data-column="' + pk + '"]').text().trim();
            }
            var field = $cell.data('column');

            if (!id || !field) return;

            // Get original value in case we need to revert
            var origValue = $cell.data('value') !== undefined ? $cell.data('value') : $cell.text().trim();

            $.ajax({
                url: window.location.href,
                method: 'POST',
                data: {
                    gc_action: 'inline_save',
                    id: id,
                    field: field,
                    value: value
                },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        // Update cell with returned display value
                        $cell.html(response.value);
                        $cell.data('value', value);
                        showAlert(response.message, 'success');
                    } else {
                        // Revert to original
                        var dispValue = $cell.data('value') !== undefined
                            ? ($cell.data('value') === origValue ? origValue : $cell.data('value'))
                            : origValue;
                        $cell.html(dispValue);
                        showAlert(response.message || 'Save failed.', 'danger');
                    }
                },
                error: function () {
                    // Revert on error
                    var dispValue = $cell.data('value') !== undefined
                        ? ($cell.data('value') === origValue ? origValue : $cell.data('value'))
                        : origValue;
                    $cell.html(dispValue);
                    showAlert('An error occurred while saving.', 'danger');
                }
            });
        }

        // Create inline editor element
        function createInlineEditor($cell, fieldType, currentValue, fieldOptions) {
            var $editor;

            switch (fieldType) {
                case 'select':
                    $editor = $('<select class="form-select form-select-sm gc-inline-select"></select>');
                    if (fieldOptions) {
                        try {
                            var options = typeof fieldOptions === 'string' ? JSON.parse(fieldOptions) : fieldOptions;
                            $.each(options, function (key, label) {
                                var $opt = $('<option></option>').attr('value', key).text(label);
                                if (String(key) === String(currentValue)) {
                                    $opt.prop('selected', true);
                                }
                                $editor.append($opt);
                            });
                        } catch (e) {
                            // Fallback to text input
                            $editor = $('<input type="text" class="form-control form-control-sm gc-inline-input">');
                        }
                    } else {
                        $editor = $('<input type="text" class="form-control form-control-sm gc-inline-input">');
                    }
                    break;

                case 'boolean':
                    $editor = $('<div class="form-check form-switch gc-inline-switch d-inline-block"></div>');
                    var $cb = $('<input type="checkbox" class="form-check-input" role="switch">')
                        .prop('checked', currentValue === '1' || currentValue === 1 || currentValue === 'true' || currentValue === true);
                    $editor.append($cb);
                    break;

                case 'number':
                    $editor = $('<input type="number" step="any" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'date':
                    $editor = $('<input type="date" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'datetime':
                    $editor = $('<input type="datetime-local" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'time':
                    $editor = $('<input type="time" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'email':
                    $editor = $('<input type="email" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'url':
                    $editor = $('<input type="url" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'tel':
                    $editor = $('<input type="tel" class="form-control form-control-sm gc-inline-input">');
                    break;

                case 'textarea':
                    $editor = $('<textarea class="form-control form-control-sm gc-inline-textarea" rows="2"></textarea>');
                    break;

                default: // text
                    $editor = $('<input type="text" class="form-control form-control-sm gc-inline-input">');
                    break;
            }

            // Set value
            if ($editor.is('input') || $editor.is('textarea')) {
                $editor.val(currentValue);
            }

            return $editor;
        }

        // Enter edit mode
        function enterEditMode($cell) {
            // Don't edit if already editing
            if ($cell.find('.gc-inline-editor').length) return;
            // Don't edit the actions column
            if ($cell.hasClass('text-center')) return;

            closeActiveEditor();

            var fieldType = $cell.data('inline-edit');
            var currentValue = $cell.data('value') !== undefined ? $cell.data('value') : '';
            var fieldOptions = $cell.data('field-options');

            // Save current display text for cancel
            $cell.data('orig-display', $cell.html());

            // Clear cell and create editor
            var $editor = createInlineEditor($cell, fieldType, currentValue, fieldOptions);
            var $editorWrap = $('<div class="gc-inline-editor"></div>').append($editor);
            $cell.addClass('gc-inline-editor-active');
            $cell.empty().append($editorWrap);

            // Focus and select
            if ($editor.is('input') && !$editor.is('[type="checkbox"]')) {
                $editor.focus().select();
            } else if ($editor.is('select') || $editor.is('textarea')) {
                $editor.focus();
            }

            // Handle save
            function doSave() {
                var val;
                if ($editor.is('select')) {
                    val = $editor.val();
                } else if ($editor.is('[type="checkbox"]')) {
                    val = $editor.prop('checked') ? '1' : '0';
                } else {
                    val = $editor.val();
                }
                saveInlineEdit($cell, val);
            }

            // Handle cancel
            function doCancel() {
                var origDisplay = $cell.data('orig-display') || '';
                $cell.removeClass('gc-inline-editor-active');
                $cell.html(origDisplay);
            }

            // Save on blur (with delay to allow click on select option)
            var blurTimer = null;
            $editor.on('blur', function () {
                blurTimer = setTimeout(function () {
                    doSave();
                }, 200);
            });

            // Cancel blur timer on focus
            $editor.on('focus', function () {
                if (blurTimer) {
                    clearTimeout(blurTimer);
                    blurTimer = null;
                }
            });

            // Save on Enter (not for textarea)
            $editor.on('keydown', function (e) {
                if (e.keyCode === 13 && !$editor.is('textarea')) {
                    e.preventDefault();
                    if (blurTimer) {
                        clearTimeout(blurTimer);
                        blurTimer = null;
                    }
                    doSave();
                }
                // Cancel on Escape
                if (e.keyCode === 27) {
                    e.preventDefault();
                    if (blurTimer) {
                        clearTimeout(blurTimer);
                        blurTimer = null;
                    }
                    doCancel();
                }
            });

            // For select, save on change
            if ($editor.is('select')) {
                $editor.on('change', function () {
                    doSave();
                });
            }

            // For checkbox/switch, save on change
            if ($editor.is('[type="checkbox"]')) {
                $editor.on('change', function () {
                    doSave();
                });
            }
        }

        // Handle double-click on editable cells
        $wrapper.off('dblclick', '[data-inline-edit]').on('dblclick', '[data-inline-edit]', function (e) {
            e.preventDefault();
            enterEditMode($(this));
        });
    }

    // ======== Init ========
    // ======== Bootstrap polyfill for non-Bootstrap themes ========
    function bootstrapPolyfill() {
        var bootstrapLoaded = typeof bootstrap !== 'undefined' && typeof bootstrap.Dropdown === 'function';

        if (!bootstrapLoaded) {
            // Dropdown polyfill — handle Bootstrap-style dropdowns for non-Bootstrap themes.
            // Materialize uses its own dropdown system (.dropdown-trigger), so it is excluded.
            if (typeof M === 'undefined') {
                $(document).on('click.dropdown', '[data-bs-toggle="dropdown"]', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var $btn = $(this);
                    var $wrapper = $btn.closest('.dropdown, .relative');
                    var $menu = $wrapper.find('.dropdown-menu, .dropdown-content, .gc-columns-menu, .gc-settings-menu');
                    if ($menu.length === 0) {
                        $menu = $btn.next('.dropdown-menu, .dropdown-content, ul');
                    }

                    // Close all other dropdowns
                    $('[data-bs-toggle="dropdown"]').not($btn).each(function () {
                        var $otherWrapper = $(this).closest('.dropdown, .relative');
                        var $otherMenu = $otherWrapper.find('.dropdown-menu, .dropdown-content, .gc-columns-menu, .gc-settings-menu');
                        if ($otherMenu.length === 0) {
                            $otherMenu = $(this).next('.dropdown-menu, .dropdown-content, ul');
                        }
                        $otherMenu.hide();
                    });

                    $menu.toggle();
                });

                // Close dropdowns on outside click
                $(document).on('click.dropdown', function (e) {
                    if (!$(e.target).closest('[data-bs-toggle="dropdown"]').length
                        && !$(e.target).closest('.dropdown-menu, .dropdown-content').length) {
                        $('.dropdown-menu, .dropdown-content, .gc-columns-menu, .gc-settings-menu').hide();
                    }
                });
            }
        }

        // Modal polyfill — always define (Bootstrap 5 is jQuery-free, doesn't define $.fn.modal)
        if (typeof $.fn.modal !== 'function') {
            $.fn.modal = function (action) {
                if (action === 'show') {
                    return this.each(function () {
                        $(this).addClass('show').css('display', 'block');
                        $('body').addClass('modal-open');
                        // Backdrop
                        if ($('.modal-backdrop').length === 0) {
                            $('body').append('<div class="modal-backdrop" style="position:fixed;top:0;left:0;width:100%;height:100%;z-index:1050;background:rgba(0,0,0,0.5)"></div>');
                        }
                    });
                }
                if (action === 'hide') {
                    return this.each(function () {
                        $(this).removeClass('show').css('display', 'none');
                        $('.modal-backdrop').remove();
                        $('body').removeClass('modal-open');
                    });
                }
            };
        }

        // Alert polyfill
        if (typeof $.fn.alert !== 'function') {
            $.fn.alert = function () {
                return this.each(function () {
                    var $alert = $(this);
                    setTimeout(function () {
                        $alert.fadeOut(function () {
                            $alert.remove();
                        });
                    }, 4000);
                });
            };
            $(document).on('click', '.gc-alert .btn-close', function () {
                $(this).closest('.gc-alert').remove();
            });
        }
    }

    $(document).ready(function () {
        bootstrapPolyfill();
        bindEvents();

        // Auto-load saved column visibility from localStorage
        $('.grocery-crud-wrapper').each(function () {
            var $wrapper = $(this);
            var url = window.location.href;
            try {
                var raw = localStorage.getItem('gc_settings_' + btoa(url));
                console.log('[GC_AUTO] url=', url, 'has_raw=', !!raw, 'menu_len=', $wrapper.find('.gc-columns-menu .form-check').length);
                if (raw) {
                    var settings = JSON.parse(raw);
                    console.log('[GC_AUTO] settings=', settings);
                    if (settings.columnOrder && settings.columnOrder.length) {
                        console.log('[GC_AUTO] applyColumnOrder', settings.columnOrder);
                        applyColumnOrder($wrapper, settings.columnOrder);
                        console.log('[GC_AUTO] after applyColumnOrder');
                    }
                    if (settings.columns) {
                        $wrapper.find('.gc-columns-menu input[type="checkbox"]').each(function () {
                            var col = $(this).data('column');
                            if (settings.columns[col] !== undefined) {
                                console.log('[GC_AUTO] toggling col', col, 'to', settings.columns[col]);
                                $(this).prop('checked', settings.columns[col]).trigger('change');
                            }
                        });
                    }
                }
            } catch (e) {
                console.log('[GC_AUTO] error', e);
            }
            // Initialize table-dragger after settings are restored
            initTableDragger($wrapper);
        });

        // Store confirmation messages
        $('.grocery-crud-wrapper').each(function () {
            var $wrapper = $(this);
            var deleteMsg = $wrapper.find('[data-confirm-delete]').data('confirm-delete');
            if (deleteMsg) {
                $wrapper.data('confirm-delete', deleteMsg);
            }
        });
    });

})(jQuery);
